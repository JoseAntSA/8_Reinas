/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ocho_Reinas;

import java.awt.*;
import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author anton
 */
public class Frame_Tablero extends JDialog{
	
    //Atributos
    private JPanel pnl, pnl2;
    private JLabel etqFondo;
    private ImageIcon imgFondo;
    private ArrayList<Integer> reinas;
    private StringBuilder cad;
    
    //Constructor
    public Frame_Tablero(JFrame padre, ArrayList<Integer> reinas, StringBuilder cad){
        super(padre, true);
        this.reinas = reinas;
        this.cad = cad;
        setTitle("Algoritmo Genetico - Problema de la 8 Reinas");
        setSize(600, 600);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);        
        initComponets();
        this.addWindowListener(new MyWindowListener());
        setVisible(true);
    }


    public void initComponets(){

        //CODIGO ATRIBUTOS
        Font fuenteTitle = new Font( "Calibri", 0, 32 );
        Font fuenteSubtitle = new Font( "Calibri", 0, 28 );        
        Font fuenteSubtitle2 = new Font( "Calibri", 0, 22 );
        Font fuenteContenido = new Font( "Calibri", 1, 18 );
        Font fuenteOptionPane = new Font( "Calibri", 1, 16 );
        Color colorGris = new Color(26,26,26);
        Color colorAzul = new Color(0,120,121);
        Color colorAzul2 = new Color(0,101,113);
        UIManager.put("OptionPane.messageFont", fuenteOptionPane);
        UIManager.put("OptionPane.messageForeground", Color.WHITE);
        UIManager.put("OptionPane.background", colorGris);
        UIManager.put("OptionPane.buttonFont", fuenteOptionPane);
        UIManager.put("Button.border", BorderFactory.createMatteBorder(5, 5, 5, 5, colorAzul));
        UIManager.put("Panel.background", colorGris);
        UIManager.put("Button.font", fuenteContenido);
        UIManager.put("Button.background", colorAzul);
        UIManager.put("Button.focus", colorAzul2);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.select", colorAzul2);

        //CODIGO PANEL
        pnl = new JPanel();
        this.getContentPane().add(pnl);
        pnl.setLayout(null);
        
        //CODIGO GRAFICA
        pnl2 = new JPanel();
        pnl2.setBackground(Color.WHITE);
        pnl2.setLayout(null);
        pnl2.setBounds(25,50,550,500);
        pnl2.setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, colorGris));
        pnl.add(pnl2);
                
        //CODIGO FONDO
        imgFondo = new ImageIcon("src/Ocho_Reinas/Img_Frame_Plano.png");
        etqFondo = new JLabel();
        etqFondo.setBounds(0, 0, 600, 600);
        etqFondo.setIcon(new ImageIcon(imgFondo.getImage().getScaledInstance(etqFondo.getWidth(), etqFondo.getHeight(), Image.SCALE_SMOOTH)));
        pnl.add(etqFondo);
        
    }
    
    public class MyWindowListener implements WindowListener {

		// Se dispara cuando se abre el formulario
		@Override
		public void windowOpened(WindowEvent e) {
                    
			JOptionPane.showMessageDialog(Frame_Tablero.this, cad);
                        Plano plano = new Plano(pnl2, reinas);
                        plano.dibujarCartesiano();
		}

		// Se activa cuando el formulario está a punto de cerrarse
		@Override
		public void windowClosing(WindowEvent e) {
			//Codigo
		}

		// Se dispara cuando se cierra el formulario
		@Override
		public void windowClosed(WindowEvent e) {
			//Codigo
		}

		// Se activa cuando la ventana está minimizada
		@Override
		public void windowIconified(WindowEvent e) {
			//Codigo
		}

		// Se activa cuando la ventana vuelve al tamaño normal
		@Override
		public void windowDeiconified(WindowEvent e) {
			//Codigo
		}

		// Se activa cuando el formulario está activado
		@Override
		public void windowActivated(WindowEvent e) {
			//Codigo
		}

		// Se activa cuando la ventana ya no está activa
		@Override
		public void windowDeactivated(WindowEvent e) {
			//Codigo
		}

	}
}
