/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ocho_Reinas;

import java.util.ArrayList;

/**
 *
 * @author anton
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame vtn = new Frame();
        /*FitnessFunction ff = new FitnessFunction();
        /*Individuo ind = new Individuo(4);
        Individuo ind2 = new Individuo(4);
        ind.init();
        ind2.init();
        
        Individuo[] hijos = ind.cruza(ind2);
        
        System.out.println(ind.str() + " ---> Score: " );
        System.out.println(ind2.str() + " ---> Score: " );
        System.out.println(hijos[0].str() + " ---> Score: " );
        System.out.println(hijos[1].str() + " ---> Score: " );
        
        ind.mutar();
       
        System.out.println(ind.str() + " ---> Score: " + ff.evaluate(ind));
        
        
        AlgoritmoEvolutivo algEv = new AlgoritmoEvolutivo(400,8);
        algEv.init();
        
        for(int i=0 ; i<500 ; i++){
            
            //int score = ff.evaluate(pob.poblacion.get(i));
            //System.out.println(pob.poblacion.get(i).str() + " ---> Score: " + score);
            algEv.evolucion();
            Individuo ind = algEv.mejorInd();
            int score = ff.evaluate(ind);
            System.out.println(ind.str() + " ---> Score: " + score);
            if (score==0)
                break;
            
        }
        
        
        */
    }
    
}
